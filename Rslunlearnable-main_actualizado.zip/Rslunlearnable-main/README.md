# Manuscrito RSL en LaTeX

El manuscrito que se edita es
[`Article_Title/v4 claude/RSL_introduccion_metodologia.tex`](Article_Title/v4%20claude/RSL_introduccion_metodologia.tex).
Las carpetas `v2` y `v3 gpt astra` son versiones anteriores.

## Preparar el entorno en otro equipo

1. **Obtener acceso.** Este [repositorio de GitHub](https://github.com/glender222/Rslunlearnable)
   es privado. El propietario debe [invitar al compañero como colaborador](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/repository-access-and-collaboration/inviting-collaborators-to-a-personal-repository),
   y el compañero debe aceptar la invitación con su cuenta de GitHub.
2. **Instalar** Git, VS Code, [Docker](https://docs.docker.com/engine/install/)
   y la extensión [LaTeX Workshop](https://github.com/James-Yu/LaTeX-Workshop/wiki/Install)
   de VS Code (`james-yu.latex-workshop`). Docker debe estar iniciado; compruébalo
   con `docker info`. En Windows, abre el proyecto con
   [VS Code conectado a WSL](https://code.visualstudio.com/docs/remote/wsl-tutorial),
   instala LaTeX Workshop en WSL y [activa la integración de Docker Desktop con esa distribución](https://docs.docker.com/desktop/features/wsl/).
3. **Clonar** el proyecto después de iniciar sesión en GitHub:

   ```bash
   git clone https://github.com/glender222/Rslunlearnable.git
   cd Rslunlearnable
   code .
   ```

   Si `code .` no está disponible, usa **Archivo → Abrir carpeta** en VS Code y
   selecciona `Rslunlearnable`. Abre la carpeta completa para que se aplique
   `.vscode/settings.json`. Si la terminal no puede autenticar el clon privado,
   usa **Git: Clone** en VS Code y sigue el inicio de sesión de GitHub.
4. **Generar el primer PDF** desde la terminal integrada de VS Code:

   ```bash
   ./compilar-v4.sh --borrador
   ```

   El primer uso construye la imagen local `rsl-latex:trixie` y puede tardar
   varios minutos. El script ejecuta pdfLaTeX, BibTeX y `latexmk` dentro de
   Docker; no hace falta instalar TeX en el equipo. El PDF queda en
   `Article_Title/v4 claude/build/RSL_introduccion_metodologia.pdf`.

## Editar y ver los cambios

1. Abre `Article_Title/v4 claude/RSL_introduccion_metodologia.tex` en VS Code.
2. Abre el PDF con **LaTeX Workshop: View LaTeX PDF** desde la paleta de comandos
   (`Ctrl+Shift+P`) y ponlo al lado del `.tex`.
3. Edita y guarda con `Ctrl+S`. La receta **Borrador (Docker)** recompila y
   actualiza **el mismo PDF** en la pestaña abierta. No crea un PDF por guardado.

Las referencias bibliográficas están en
`Article_Title/v4 claude/sn-bibliography.bib`. Si hay un error de compilación,
abre **Ver → Problemas** en VS Code. Para el registro del compilador, abre
**Ver → Salida** y elige **LaTeX Compiler**, o busca **LaTeX Workshop: View LaTeX
compiler logs** en la paleta de comandos. También puedes consultar
`Article_Title/v4 claude/build/RSL_introduccion_metodologia.log`.

## Figura PRISMA y compilación final

La descarga original no incluye `prisma_2020_RSL.png`. El modo borrador muestra
un marcador en su lugar. Cuando se obtenga la figura de Overleaf, guárdala en
`Article_Title/v4 claude/` con ese nombre y súbela también a GitHub para que
todos los colaboradores la tengan. Entonces usa **LaTeX Workshop: Build with
recipe → Final (Docker)** o ejecuta `./compilar-v4.sh`. Borrador y Final
actualizan el mismo PDF de trabajo.

## Compartir cambios

Antes de empezar, ejecuta `git pull --ff-only origin main`. Si varias personas
editan el manuscrito, cada una debe trabajar en una rama, subirla y abrir una
solicitud de cambios hacia `main`. Si Git pide identificar al autor, configura
`git config user.name "Tu nombre"` y `git config user.email "tu-correo"` en la
carpeta clonada. Ejemplo de rama:

```bash
git switch -c introduccion-nombre
# Edita y guarda el .tex.
git add "Article_Title/v4 claude/RSL_introduccion_metodologia.tex"
git commit -m "Actualiza la introducción"
git push -u origin introduccion-nombre
```

Si modificaste la bibliografía o agregaste una figura, inclúyelas también en
el commit. Los PDF y archivos auxiliares de `build/` están excluidos de Git:
GitHub conserva las versiones del código fuente, y cada equipo genera su PDF
localmente.
