#!/usr/bin/env bash
set -euo pipefail

carpeta="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
imagen='wuhanstudio/biblioshiny@sha256:9d61068788f5b72f07e3064f812b9dadc7f1d2a953bb1efbe06f64be5529f36b'
mkdir -p "$carpeta/resultados_bibliometrix"
docker run --rm \
  --user "$(id -u):$(id -g)" \
  --mount "type=bind,source=$carpeta,target=/datos,readonly" \
  --mount "type=bind,source=$carpeta/resultados_bibliometrix,target=/salida" \
  --entrypoint Rscript "$imagen" \
  /datos/generar_graficos.R '/datos/bibtex_maestro (2).bib' /salida
