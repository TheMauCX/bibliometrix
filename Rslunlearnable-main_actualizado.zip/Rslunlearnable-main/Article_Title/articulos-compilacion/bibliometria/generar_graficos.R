#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(bibliometrix))
suppressPackageStartupMessages(library(ggplot2))
suppressPackageStartupMessages(library(igraph))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Uso: generar_graficos.R archivo.bib directorio_salida")
bib <- args[[1]]
salida <- args[[2]]
dir.create(salida, recursive = TRUE, showWarnings = FALSE)

# El maestro es un BibTeX normalizado que combina cuatro plataformas.
# bibliometrix 2.3.3 requiere readFiles() antes de convert2df().
M <- convert2df(readFiles(bib), dbsource = "generic", format = "bibtex")
if (nrow(M) != 343L) stop("Se esperaban 343 registros únicos; se importaron ", nrow(M))

# El campo `source` del maestro dice Scopus en todos los registros; la
# procedencia real se conserva en `db_source` y se recupera en orden.
lineas <- readLines(bib, warn = FALSE, encoding = "UTF-8")
lineas_fuente <- grep("^[[:space:]]*db_source[[:space:]]*=", lineas, value = TRUE)
fuente <- trimws(sub("^[[:space:]]*db_source[[:space:]]*=[[:space:]]*\\{([^}]*)\\}.*$", "\\1", lineas_fuente))
if (length(fuente) != nrow(M)) stop("No coincide el número de fuentes y registros")
esperado <- c(Scopus = 109L, SpringerLink = 221L, IEEE = 11L, `Web of Science` = 2L)
if (!identical(as.integer(table(factor(fuente, levels = names(esperado)))), as.integer(esperado))) {
  stop("Cambió la composición por base de datos; revisar el maestro antes de graficar")
}
M$DB <- fuente

# El export conserva los nombres completos de autor; el importador antiguo
# los abrevia a iniciales. Restaurarlos reduce homónimos en la red.
lineas_autor <- grep("^[[:space:]]*author[[:space:]]*=", lineas, value = TRUE)
autores_bib <- sub("^[[:space:]]*author[[:space:]]*=[[:space:]]*\\{(.*)\\},?[[:space:]]*$", "\\1", lineas_autor)
if (length(autores_bib) != nrow(M)) stop("No coincide el número de campos de autor")
autores_completos <- vapply(strsplit(autores_bib, " and ", fixed = TRUE),
                            function(x) paste(toupper(trimws(x)), collapse = ";"), character(1))
M_red <- M
M_red$AU <- autores_completos

analisis <- biblioAnalysis(M)
bradford_resultado <- bradford(M)
save(M, file = file.path(salida, "coleccion_bibliometrix.RData"))

tema <- theme_minimal(base_size = 13) +
  theme(plot.title = element_text(face = "bold", size = 16),
        plot.subtitle = element_text(size = 11),
        plot.caption = element_text(size = 9, colour = "#555555"),
        panel.grid.minor = element_blank())
pie <- "Fuente: bibtex_maestro (2).bib; análisis con bibliometrix 2.3.3. n = 343 registros únicos de bases."

guardar <- function(grafico, nombre, ancho = 10, alto = 6) {
  ggsave(file.path(salida, paste0(nombre, ".png")), grafico,
         width = ancho, height = alto, units = "in", dpi = 220, bg = "white")
  ggsave(file.path(salida, paste0(nombre, ".pdf")), grafico,
         width = ancho, height = alto, units = "in", device = cairo_pdf, bg = "white")
}

# 1. Serie temporal de producción (campo PY completo).
por_ano <- as.data.frame(table(M$PY), stringsAsFactors = FALSE)
names(por_ano) <- c("ano", "n")
por_ano$ano <- as.integer(as.character(por_ano$ano))
grafico <- ggplot(por_ano, aes(x = ano, y = n)) +
  geom_area(fill = "#7faec5", alpha = 0.6) +
  geom_line(colour = "#1d5f84", size = 1.3) +
  geom_point(colour = "#1d5f84", size = 3) +
  geom_text(aes(label = n), vjust = -0.7, size = 4) +
  scale_x_continuous(breaks = 2020:2026) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.1))) +
  labs(title = "Producción científica por año", subtitle = "Registros recuperados en las cuatro bases; 2026 es un año incompleto",
       x = "Año de publicación", y = "Publicaciones", caption = pie) + tema
guardar(grafico, "01_produccion_anual")

# 2. Mapa de calor de año por base de procedencia.
procedencia <- as.data.frame(table(ano = M$PY, base = M$DB), stringsAsFactors = FALSE)
names(procedencia)[[3]] <- "n"
procedencia$base <- factor(procedencia$base,
                           levels = c("Scopus", "Web of Science", "IEEE", "SpringerLink"))
grafico <- ggplot(procedencia, aes(x = ano, y = base, fill = n)) +
  geom_tile(colour = "white", size = 1) +
  geom_text(aes(label = ifelse(n == 0, "", n)), size = 4) +
  scale_fill_gradient(low = "#edf4f6", high = "#197a7e", name = "Registros") +
  labs(title = "Año y base de procedencia", subtitle = "Mapa de calor de los 343 registros únicos; la base indica atribución del maestro",
       x = "Año de publicación", y = NULL, caption = pie) + tema
guardar(grafico, "02_ano_por_base", 10, 5.5)

# 3. Zonas de Bradford calculadas por la función bradford() de bibliometrix.
zonas <- bradford_resultado$table
zonas$Zone <- factor(zonas$Zone, levels = c("Zone 1", "Zone 2", "Zone 3"),
                     labels = c("Zona 1", "Zona 2", "Zona 3"))
grafico <- ggplot(zonas, aes(x = Rank, y = cumFreq, colour = Zone)) +
  geom_line(size = 1.2) + geom_point(size = 0.8) +
  scale_colour_manual(values = c("#1d5f84", "#d28b32", "#7d687e"), name = "Bradford") +
  scale_x_continuous(breaks = c(1, 24, 50, 105, 150, 218)) +
  scale_y_continuous(breaks = c(0, 115, 230, 343), limits = c(0, 343)) +
  labs(title = "Concentración de fuentes según Bradford",
       subtitle = "24 fuentes reúnen 115 registros; otras 81 reúnen 115 y 113 reúnen 113",
       x = "Rango de la fuente por productividad", y = "Publicaciones acumuladas", caption = pie) + tema
guardar(grafico, "03_bradford")

guardar_red <- function(matriz, nodos, archivo, titulo, subtitulo, umbral = 1) {
  sub <- as.matrix(matriz[nodos, nodos, drop = FALSE])
  diag(sub) <- 0
  sub[sub < umbral] <- 0
  red <- graph_from_adjacency_matrix(sub, mode = "undirected", weighted = TRUE, diag = FALSE)
  red <- delete.vertices(red, V(red)[degree(red) == 0])
  if (vcount(red) < 3 || ecount(red) < 2) stop("Red demasiado pequeña: ", archivo)
  set.seed(2026)
  disposicion <- layout_with_fr(red, weights = E(red)$weight)
  colores <- c("#1d5f84", "#197a7e", "#d28b32", "#7d687e", "#a56348", "#536b9b")
  comunidades <- membership(cluster_louvain(red, weights = E(red)$weight))
  nodos_color <- colores[(comunidades - 1) %% length(colores) + 1]
  tamano <- 6 + 2.5 * sqrt(strength(red, weights = E(red)$weight))
  pintar <- function() {
    par(mar = c(3, 1, 4, 1), family = "sans")
    plot(red, layout = disposicion, vertex.size = tamano,
         vertex.color = nodos_color, vertex.frame.color = "white",
         vertex.label.color = "#222222", vertex.label.cex = 0.64,
         vertex.label.dist = 0.35, edge.color = "#9aa8af80",
         edge.width = 0.5 + sqrt(E(red)$weight), main = titulo,
         margin = 0.12)
    mtext(subtitulo, side = 3, line = 0.2, cex = 0.78, col = "#555555")
    mtext("Fuente: bibtex_maestro (2).bib; bibliometrix 2.3.3.", side = 1,
          line = 1.5, cex = 0.7, col = "#555555")
  }
  png(file.path(salida, paste0(archivo, ".png")), width = 2400, height = 1800, res = 220, type = "cairo")
  pintar()
  dev.off()
  cairo_pdf(file.path(salida, paste0(archivo, ".pdf")), width = 11, height = 8.25)
  pintar()
  dev.off()
  cat(archivo, ": ", vcount(red), " nodos, ", ecount(red), " aristas\n", sep = "")
}

# 4. Red de colaboración calculada por biblioNetwork() con nombres completos.
red_autores <- biblioNetwork(M_red, analysis = "collaboration", network = "authors", sep = ";")
frecuencia_autor <- sort(table(unlist(strsplit(M_red$AU, ";", fixed = TRUE))), decreasing = TRUE)
seleccion_autores <- intersect(names(head(frecuencia_autor, 35)), rownames(red_autores))
guardar_red(red_autores, seleccion_autores, "04_red_coautoria",
           "Red de coautoría", "35 autores con más registros; aristas = publicaciones compartidas; n = 343")

# 5. Red de coocurrencia: solo registros que traen palabras clave de autor.
con_de <- M[!is.na(M$DE) & nzchar(M$DE), , drop = FALSE]
if (nrow(con_de) != 77L) stop("Cambió la cobertura de palabras clave de autor")
red_de <- biblioNetwork(con_de, analysis = "co-occurrences", network = "author_keywords", sep = ";")
frecuencia_de <- sort(table(trimws(unlist(strsplit(con_de$DE, ";", fixed = TRUE)))), decreasing = TRUE)
seleccion_de <- intersect(names(head(frecuencia_de, 28)), rownames(red_de))
guardar_red(red_de, seleccion_de, "05_red_palabras_clave",
           "Red de palabras clave de autor",
           "28 términos más frecuentes; solo 77 de 343 registros tienen este campo", umbral = 2)

cat("Generados 5 gráficos (PNG y PDF) y colección Biblioshiny en ", salida, "\n", sep = "")
