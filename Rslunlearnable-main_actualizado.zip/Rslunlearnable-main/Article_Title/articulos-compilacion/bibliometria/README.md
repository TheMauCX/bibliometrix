# Gráficos bibliométricos

El archivo `bibtex_maestro (2).bib` contiene los **343 registros únicos recuperados de bases de datos** para el cribado de esta revisión. No equivale al corpus final de 39 estudios incluidos. Los gráficos de `resultados_bibliometrix/` describen esos 343 registros y **no están insertados en el manuscrito**.

## Generar de nuevo

Con Docker disponible, desde esta carpeta:

```bash
./ejecutar.sh
```

El script fija una imagen con Biblioshiny/bibliometrix 2.3.3 e importa el maestro mediante `readFiles()` y `convert2df(dbsource = "generic", format = "bibtex")`. Después usa `biblioAnalysis()` y `bradford()` para las métricas. Los resultados son cinco gráficos en PNG y PDF y `coleccion_bibliometrix.RData`, que contiene el objeto `M` para explorarlo en R/Biblioshiny. El archivo BibTeX original no se modifica.

La generación funciona por código y no abre ninguna interfaz. Docker solo proporciona R con bibliometrix 2.3.3 instalado. Si bibliometrix está instalado localmente, también se puede ejecutar `Rscript generar_graficos.R 'bibtex_maestro (2).bib' resultados_bibliometrix` desde esta carpeta.

| Gráfico | Campo o cálculo | Cobertura |
| --- | --- | --- |
| 01 Producción anual | Año `PY` | 343/343 |
| 02 Fuentes principales | Fuente editorial `SO` | 343/343 |
| 03 Bradford | `bradford(M)` sobre `SO` | 343/343 |
| 04 Autores por publicación | `nAUperPaper` | 343/343 |
| 05 Tipos de documento | Tipo `DT` del export | 343/343 |

La atribución por base de datos se toma de `db_source` (Scopus 109, SpringerLink 221, IEEE 11, Web of Science 2). El campo `source` del maestro dice “Scopus” en todos los registros y no sirve para esa atribución. Los datos de palabras clave, afiliación y referencias son incompletos, por lo que no se usan para mapas de temas, países o citas. Las etiquetas de tipo documental reflejan el export bibliográfico; no prueban elegibilidad para la RSL. La producción de 2026 corresponde a un año incompleto.

**Referencias del programa:** [Biblioshiny](https://www.bibliometrix.org/biblioshiny/) y [manual de importación de bibliometrix](https://github.com/massimoaria/bibliometrix/blob/master/man/convert2df.Rd).
