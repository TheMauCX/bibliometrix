#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source_dir="$project_dir/Article_Title/v4 claude"
image_name="rsl-latex:trixie"
mode="${1:-}"

if [[ "$#" -gt 1 || ( -n "$mode" && "$mode" != "--borrador" ) ]]; then
    printf 'Uso: %s [--borrador]\n' "$0" >&2
    exit 2
fi

if [[ "$mode" != "--borrador" && ! -f "$source_dir/prisma_2020_RSL.png" ]]; then
    printf 'Falta la figura original: %s\n' "$source_dir/prisma_2020_RSL.png" >&2
    printf 'Descárgala de Overleaf o usa --borrador para una vista previa.\n' >&2
    exit 1
fi

if ! docker image inspect "$image_name" >/dev/null 2>&1; then
    docker build -f "$project_dir/Dockerfile.latex" -t "$image_name" "$project_dir"
fi

mkdir -p "$source_dir/build"

docker_args=()
if [[ "$mode" == "--borrador" ]]; then
    placeholder_dir="$source_dir/build/preview-assets"
    placeholder_file="$placeholder_dir/prisma_2020_RSL.png"
    mkdir -p "$placeholder_dir"
    if ! cmp -s "$project_dir/assets/prisma_placeholder.png" "$placeholder_file"; then
        cp "$project_dir/assets/prisma_placeholder.png" "$placeholder_file"
    fi
    docker_args+=(--env 'TEXINPUTS=/work/build/preview-assets:')
fi

build_mode="final"
if [[ "$mode" == "--borrador" ]]; then
    build_mode="borrador"
fi
force_args=()
if [[ ! -f "$source_dir/build/.compile-mode" ]] ||
   [[ "$(cat "$source_dir/build/.compile-mode")" != "$build_mode" ]]; then
    force_args+=(-g)
fi

docker run --rm \
    --user "$(id -u):$(id -g)" \
    --env HOME=/tmp \
    "${docker_args[@]}" \
    --mount "type=bind,src=$source_dir,dst=/work" \
    --workdir /work \
    "$image_name" \
    latexmk -pdf -synctex=1 -interaction=nonstopmode -halt-on-error \
    -file-line-error "${force_args[@]}" -outdir=build \
    RSL_introduccion_metodologia.tex

printf '%s\n' "$build_mode" > "$source_dir/build/.compile-mode"
printf 'PDF: %s\n' "$source_dir/build/RSL_introduccion_metodologia.pdf"
